from setuptools import setup

setup(name='grgym',
      version='0.0.2',
      install_requires=['gym>=0.2.3', 'ruamel.yaml', 'sh>=1.10.0']
)
